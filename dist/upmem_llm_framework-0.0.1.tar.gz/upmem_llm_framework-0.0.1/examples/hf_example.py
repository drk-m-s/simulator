import argparse
import sys
import time
import torch

import transformers

import upmem_llm_framework.pytorch_upmem_layers as upmem_layers
upmem_layers.profiler_init()

hf_token = "your_token"

model     = transformers.AutoModelForCausalLM.from_pretrained("meta-llama/Llama-2-7b-chat-hf", use_auth_token=hf_token)
tokenizer = transformers.AutoTokenizer.from_pretrained       ("meta-llama/Llama-2-7b-chat-hf", use_auth_token=hf_token)

# 't' indicates when the input of a layer
# comes from HOST. This produces 2 transfers:  
#     - last device -> HOST
#     - HOST        -> new device
# layer_mapping = {
#    "LlamaRMSNorm"    : "PIM-AI-1chip,t",
#    "q_proj"	       : "PIM-AI-4chip,t",
#    "k_proj"	       : "PIM-AI-4chip"  ,
#    "rotary_emb"      : "PIM-AI-4chip"  ,
#    "v_proj"          : "PIM-AI-4chip"  ,
#    "o_proj"          : "PIM-AI-4chip,t",
#    "output_layernorm": "PIM-AI-1chip,t",
#    "gate_proj"       : "PIM-AI-4chip,t",
#    "up_proj"         : "PIM-AI-4chip,t",
#    "down_proj"       : "PIM-AI-4chip,t",
#    "norm"            : "PIM-AI-1chip,t",
#    "lm_head"         : "PIM-AI-4chip,t"
# }

layer_mapping = {
   "input_layernorm" : "PIM-AI-1chip",
   "q_proj"	         : "PIM-AI-1chip",
   "k_proj"	         : "PIM-AI-1chip",
   "rotary_emb"      : "PIM-AI-1chip",
   "v_proj"          : "PIM-AI-1chip",
   "o_proj"          : "PIM-AI-1chip",
   "output_layernorm": "PIM-AI-1chip",
   "gate_proj"       : "PIM-AI-1chip",
   "up_proj"         : "PIM-AI-1chip",
   "down_proj"       : "PIM-AI-1chip",
   "norm"            : "PIM-AI-1chip",
   "lm_head"         : "PIM-AI-1chip"
}


prompt = "How to prepare coffee?"

inputs = tokenizer(prompt, return_tensors="pt", return_token_type_ids=False)

print (inputs.data["input_ids"][0].shape)
model.eval() # Put model in evaluation / inference mode

#print (model)

upmem_layers.profiler_start(layer_mapping)
#start = time.time_ns() # In case we want to time the original execution (comment out profiler_start)
gen_tokens = model.generate(inputs.input_ids,
                            do_sample=True,
                            temperature=0.9,
		                    min_length=64,
                            max_length=64)
#print ( (time.time_ns() - start)/1e6)
upmem_layers.profiler_end  ()

gen_text = tokenizer.batch_decode(gen_tokens, skip_special_tokens=True, clean_up_tokenization_spaces=False)[0]
print (gen_text)
