#
# Copyright (c) 2014-2024 - UPMEM
# UPMEM S.A.S France property - UPMEM confidential information covered by NDA
# For UPMEM partner internal use only - no modification allowed without permission of UPMEM
#
# This file wraps PyTorch classes and functions into new UPM classes and functions able to
# track the start, inputs, end and outputs of the corresponding function.
# Currently, forward from multiple modules and other minor functions
# (normalizations, softmax, activations, etc.) are tracked and profiled.

import argparse
from .profiler import UPM_Profiler
import torch
from torch import Tensor
from typing import Optional, Union  # , Tuple
from inspect import getframeinfo, stack
from torch.nn.common_types import _size_1_t

import transformers

options = None
profiler = None
profiling = 0


def get_arguments():
    parser = argparse.ArgumentParser()
    # Verbose related
    parser.add_argument(
        "--report-layers",
        action="store_true",
        help="Enable reporting metrics for all executed layers at the end of the forward pass.",
    )
    parser.add_argument(
        "--report-functions",
        action="store_true",
        help="Enable reporting metrics for all executed functions at the end of the forward pass.",
    )
    parser.add_argument(
        "--print-log",
        action="store_true",
        help="Print a trace of the execution of layers and functions.",
    )
    parser.add_argument(
        "--print-log-summary",
        action="store_true",
        help="Print a detailed summary of each layer and function executed. For summarization, generation, and both.",
    )
    # Simulation related
    parser.add_argument(
        "--simulation",
        action="store_true",
        help="Enable simulation according to the layer mapping defined",
    )
    parser.add_argument(
        "--sim-compute",
        action="store_true",
        help="Simulate compute intensive operations. Note that some operations are still performed due to constraints in inputs/outputs of other layer/functions. CAUTION: Output tokens will be affected",
    )
    parser.add_argument(
        "--sim-data-type",
        choices=["int4", "int8", "float16", "bfloat16", "float32"],
        default="bfloat16",
        help="Set the datatype for weights and inputs.",
    )
    parser.add_argument(
        "--sim-num-key-value-heads",
        type=int,
        default=-1,
        help="When using GQA, this value is used to simulate fetching the correct KV caches.",
    )
    parser.add_argument(
        "--sim-sliding-window",
        type=int,
        default=-1,
        help="When set, a sliding window is simulated according to this value. Note that the real underlying execution will run according to the model parameter.",
    )
    parser.add_argument(
        "--sim-verbose",
        action="store_true",
        help="Set a verbose mode for simulation",
    )
    toReturn, _ = parser.parse_known_args()
    return toReturn


def get_context():
    # https://stackoverflow.com/questions/24438976/debugging-get-filename-and-line-number-from-which-a-function-is-called
    return getframeinfo(stack()[2][0]).code_context[0].split()[0].replace("self.", "")


class UPM_Module(torch.nn.Module):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def forward(self, x):
        x = super().forward(x)
        return x


class UPM_Linear(torch.nn.Linear):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        profiler.add(self, get_context())

    def forward(self, x):
        context = get_context()
        profiler.forward_start(x.shape)
        if options.sim_compute:
            shape = list(x.shape)
            shape[-1] = self.out_features
            x = torch.zeros(shape)
        else:
            x = super().forward(x)
        profiler.forward_end(x.shape, context, layer_obj=self)
        return x


class UPM_LayerNorm(torch.nn.LayerNorm):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        profiler.add(self, get_context())

    def forward(self, x):
        context = get_context()
        profiler.forward_start(x.shape)
        x = super().forward(x)
        profiler.forward_end(x.shape, context, layer_obj=self)
        return x


class UPM_Embedding(torch.nn.Embedding):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        profiler.add(self, get_context())

    def forward(self, x):
        context = get_context()
        profiler.forward_start(x.shape)
        x = super().forward(x)
        profiler.forward_end(x.shape, context, layer_obj=self)
        return x


class UPM_LlamaRotaryEmbedding(
    transformers.models.llama.modeling_llama.LlamaRotaryEmbedding
):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        profiler.add(self, get_context())

    def forward(self, x, position_ids):
        context = get_context()
        shape = x.shape
        profiler.forward_start(shape)
        x = super().forward(x, position_ids)
        profiler.forward_end(shape, context, layer_obj=self)  # TODO: x is a tuple
        return x


class UPM_LlamaRMSNorm(transformers.models.llama.modeling_llama.LlamaRMSNorm):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        profiler.add(self, get_context())

    def forward(self, x):
        context = get_context()
        profiler.forward_start(x.shape)
        x = super().forward(x)
        profiler.forward_end(x.shape, context, layer_obj=self)
        return x


class UPM_SiLUActivation(transformers.activations.SiLUActivation):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        profiler.add(self, get_context())

    def forward(self, x):
        context = get_context()
        profiler.forward_start(x.shape)
        x = super().forward(x)
        profiler.forward_end(x.shape, context, layer_obj=self)
        return x


class UPM_NewGELUActivation(transformers.activations.NewGELUActivation):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        profiler.add(self, get_context())

    def forward(self, x):
        context = get_context()
        profiler.forward_start(x.shape)
        x = super().forward(x)
        profiler.forward_end(x.shape, context, layer_obj=self)
        return x


class UPM_Dropout(torch.nn.Dropout):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        profiler.add(self, get_context())

    def forward(self, x):
        context = get_context()
        profiler.forward_start(x.shape)
        x = super().forward(x)
        profiler.forward_end(x.shape, context)
        return x


class UPM_Conv1d(torch.nn.Conv1d):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        profiler.add(self, get_context())


class UPM_Conv1D(transformers.pytorch_utils.Conv1D):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        profiler.add(self, get_context())

    def forward(self, x):
        context = get_context()
        profiler.forward_start(x.shape)
        x = super().forward(x)
        profiler.forward_end(x.shape, context)
        return x


class UPM_Softmax(torch.nn.Softmax):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        profiler = profiler
        profiler.add(self, get_context())

    def forward(self, x):
        profiler.forward_start()
        x = super().forward(x)
        profiler.forward_end()
        return x


class UPM_Tensor(torch.Tensor):

    def transpose(self, input, dim0, dim1):
        print("MyTranpose with input:", input, "dim0", dim0, "dim1", dim1)
        super(MyTensor, self).transpose(input, dim0, dim1)


__pytorch_nn_functional_softmax = torch.nn.functional.softmax


def UPM_Softmax_functional(input, dim=None, dtype=None):
    context = get_context()
    profiler.forward_func_start("softmax", context, input.shape)
    x = __pytorch_nn_functional_softmax(input, dim=dim, dtype=dtype)
    profiler.forward_func_end("softmax", context, x.shape)
    return x


__pytorch_matmul = torch.matmul


def UPM_Matmul(input, other, *, out=None):
    context = get_context()
    profiler.forward_func_start("matmul", context, input.shape)
    x = __pytorch_matmul(input, other, out=out)
    profiler.forward_func_end("matmul", context, x.shape)
    return x


__pytorch_scaled_dot_product_attention = (
    torch.nn.functional.scaled_dot_product_attention
)


def UPM_scaled_dot_product_attention(query, key, value, **kwargs):
    context = get_context()
    profiler.forward_func_start("scaled_dot_product_attention", context, key.shape)
    if options.sim_compute:
        q_shape = list(query.shape)
        v_shape = list(value.shape)
        q_shape[-1] = v_shape[-1]
        x = torch.zeros(q_shape)
    else:
        x = __pytorch_scaled_dot_product_attention(query, key, value, **kwargs)
    profiler.forward_func_end("scaled_dot_product_attention", context, x.shape)
    return x


__pytorch_transpose = torch.transpose


def UPM_Transpose(input, dim0, dim1):
    context = get_context()
    print("UPM_Transpose with input", input.shape, "dim0:", dim0, "dim1", dim1)
    x = __pytorch_transpose(input, dim0, dim1)
    return x


def profiler_init():

    global options
    options = get_arguments()

    global profiling, profiler
    profiling = 1
    profiler = UPM_Profiler(options)

    # torch library
    torch.nn.Module = UPM_Module
    torch.nn.Linear = UPM_Linear
    torch.nn.LayerNorm = UPM_LayerNorm
    torch.nn.Embedding = UPM_Embedding
    torch.nn.Dropout = UPM_Dropout
    torch.nn.Conv1d = UPM_Conv1d
    torch.nn.Softmax = UPM_Softmax
    torch.nn.functional.softmax = UPM_Softmax_functional
    torch.matmul = UPM_Matmul
    torch.transpose = UPM_Transpose
    torch.nn.functional.scaled_dot_product_attention = UPM_scaled_dot_product_attention
    # torch.Tensor = UPM_Tensor

    # transformers library
    transformers.pytorch_utils.Conv1D = UPM_Conv1D
    transformers.activations.NewGELUActivation = UPM_NewGELUActivation
    transformers.activations.ACT2FN["gelu_new"] = (
        UPM_NewGELUActivation  # classes are hardcoded in ACT2FN
    )
    transformers.activations.ACT2FN["silu"] = (
        UPM_SiLUActivation  # classes are hardcoded in ACT2FN
    )
    transformers.models.llama.modeling_llama.LlamaRMSNorm = UPM_LlamaRMSNorm
    transformers.models.llama.modeling_llama.LlamaRotaryEmbedding = (
        UPM_LlamaRotaryEmbedding
    )

    transformers.models.mixtral.modeling_mixtral.MixtralRMSNorm = UPM_LlamaRMSNorm
    transformers.models.mistral.modeling_mistral.MistralRMSNorm = UPM_LlamaRMSNorm


def profiler_start(
    layer_mapping={},
    layer_attn_ctxt="",
    last_layer="lm_head",
    batch_size=1,
    moe_end="",
    experts_per_token=2,
):
    global options
    profiler.set_options(options)
    profiler.start(
        layer_mapping=layer_mapping,
        layer_attn_ctxt=layer_attn_ctxt,
        last_layer=last_layer,
        batch_size=1,
        moe_end=moe_end,
        experts_per_token=experts_per_token,
    )


def profiler_end():
    profiler.end()
